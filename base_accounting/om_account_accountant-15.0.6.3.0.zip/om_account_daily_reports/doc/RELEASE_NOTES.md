## Module <om_account_daily_reports>

#### 15.04.2022
#### Version 15.0.2.2.0
##### FIX
- fix if Outstanding account set on journal not company settings

#### 15.04.2022
#### Version 15.0.2.1.0
##### IMP
- turkish translation

#### 03.03.2022
#### Version 15.0.2.0.0
##### IMP
- code refactoring
